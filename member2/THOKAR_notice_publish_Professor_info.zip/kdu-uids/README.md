# KDU Global UIDS - Member 2 module

University Information Display System (UIDS) for KDU Global (Kyungdong
University), Goseong-gun, South Korea. Bachelor in Smart Computing final
project, team plan UIDS-03.

This repository is the **Member 2 module (developer code B, packages B01-B08)**:
notice publishing with review, events, and the professor directory. It is a
MERN stack MVP (MongoDB, Express, React, Node.js) that runs on its own.

## Module scope

| Area | Owner | In this repo |
|---|---|---|
| Notice publishing, review workflow, corrections, scheduling | **Member 2 (B)** | Full implementation |
| Events linked to notices (postpone, cancel, calendar) | **Member 2 (B)** | Full implementation |
| Professor directory and admin CRUD | **Member 2 (B)** | Full implementation |
| Domain events (idempotent) and audit log | **Member 2 (B)** | Full implementation; payload contract in `docs/CONTRACTS.md` |
| Accounts, security, attachment gateway | Member 1 (A) | Simple replaceable versions: `modules/auth`, `modules/users`, and `modules/attachments/localAttachmentGateway.js` (marked TEMPORARY EXTERNAL INTEGRATION BOUNDARY) |
| Public discovery, unified search, notifications | Member 4 (D) | Public pages here are basic; notifications are only recorded as domain events with `deliveryStatus: PENDING` |
| Integration, shared taxonomy, administration | L (Mahato Nitesh) | Departments are a seeded collection; names are editable sample data |

**Sample data notice.** All professor names, emails, phone numbers, notices
and events are fictional (emails use the reserved `example.edu` domain).
The six department full names (Artificial Intelligence, International
Business Administration, Bachelor of Smart Computing, International
Hospitality Management, Korean Studies, English for Academic Purposes) are
**editable sample data** and must be confirmed by the university.

## Requirements

- Node.js 20 LTS or newer, npm 10
- MongoDB 7 **running as a replica set** (needed for transactions). Pick one:
  Docker, a local replica set, or MongoDB Atlas (see below).

## Installation

```bash
npm install                      # installs both workspaces (server, client)
cp server/.env.example server/.env
cp client/.env.example client/.env
# edit server/.env: set JWT_SECRET to a random string of 32+ characters, e.g.
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

## MongoDB setup (choose one)

**A. Docker compose (simplest)**

```bash
docker compose up -d             # MongoDB 7 single-node replica set "rs0" on port 27017
```

Keep `MONGO_URI=mongodb://127.0.0.1:27017/kdu_uids?replicaSet=rs0`.

**B. Local replica set**

```bash
mkdir -p ~/data/rs0
mongod --replSet rs0 --dbpath ~/data/rs0 --port 27017 --bind_ip 127.0.0.1
# in another terminal, once:
mongosh --eval "rs.initiate({ _id: 'rs0', members: [{ _id: 0, host: '127.0.0.1:27017' }] })"
```

**C. MongoDB Atlas.** Atlas clusters are replica sets. Put the connection
string in `MONGO_URI`, for example
`mongodb+srv://user:pass@cluster0.xxxxx.mongodb.net/kdu_uids`.

Without a replica set the server still runs: it saves the state first and
then records the domain event, relying on idempotency for safe retries.

## Environment variables (server/.env)

| Variable | Default | Meaning |
|---|---|---|
| NODE_ENV | development | development, test or production |
| PORT | 5000 | API port |
| MONGO_URI | - | MongoDB connection string (replica set) |
| JWT_SECRET | - | **Required, 32+ characters.** The server refuses to start otherwise |
| JWT_EXPIRES_IN | 1h | Session length, 15m to 1h |
| CLIENT_ORIGIN | http://localhost:5173 | Allowed CORS origin |
| UNIVERSITY_TZ | Asia/Seoul | University time zone |
| UPLOAD_DIR | ./storage/uploads | Attachment storage, outside any public folder |
| MAX_PINNED_NOTICES | 5 | Pinned notice limit |
| ENABLE_STATUS_SYNC | false | Optional cache job; never used for visibility |
| BCRYPT_ROUNDS | 12 | Password hashing cost (12+ enforced in production) |
| AUTH_LOGIN_RATE_LIMIT | 5 | Login attempts per minute per IP + email |
| AUTH_RATE_LIMIT | 100 | Requests to /api/auth per 15 minutes per IP |

Client (`client/.env`): `VITE_API_BASE_URL=/api`, `VITE_UNIVERSITY_TZ=Asia/Seoul`.
The Vite dev server proxies `/api` to `http://localhost:5000`, so cookies are same-origin.

## Running

```bash
npm run seed       # reset and seed the database (safe to run again)
npm run dev        # API on :5000 and web app on :5173 together
npm run server     # API only (nodemon)
npm run client     # web app only
npm run build      # production build of the client (client/dist)
```

Open http://localhost:5173.

## Seeded accounts (development only)

| Email | Password | Role |
|---|---|---|
| admin@kdu-uids.test | Admin@12345 | ADMIN |
| author@kdu-uids.test | Author@12345 | AUTHOR |
| author2@kdu-uids.test | Author@12345 | AUTHOR (for the concurrency demo) |
| reviewer@kdu-uids.test | Reviewer@12345 | REVIEWER |
| reader@kdu-uids.test | Reader@12345 | READER |

The seed creates 15 notices (4 live published including one pinned URGENT,
one HIGH, one with an action deadline and one CAMPUS-only; plus a draft,
submitted, returned, rejected, scheduled (+3 days), expired (-1 day),
withdrawn, archived, a published notice with a pending correction, and two
more published event notices), 6 events (upcoming, completed, postponed with
history, cancelled with reason, one hidden under the scheduled notice, one
campus-only), 18 professors (3 per department), domain events and audit
entries. All dates are relative to the time the seed runs.

## Tests

```bash
npm test               # backend (Jest + Supertest + mongodb-memory-server replica set) and frontend (Vitest)
npm run test:server    # backend only
npm run lint
npm run smoke          # optional: end-to-end check against a running, freshly seeded server
```

mongodb-memory-server downloads a MongoDB binary the first time. If your
network blocks that download, point it at a local binary:
`MONGOMS_SYSTEM_BINARY=/path/to/mongod npm test`.

Describe blocks are named by test ID so results map to the evidence record:
`T03` (publication), `T04` (time boundaries, corrections, concurrency,
withdrawal), `T12` (events, domain events, audit), `PROF`, `SEC`, `AUTH`,
and `FE` (frontend).

### Latest results (actual run)

| Suite | Passed | Failed |
|---|---|---|
| T03 Publication (`notices.publication.test.js`) | 14 | 0 |
| T04 Time and revisions (`notices.time-revisions.test.js`) | 19 | 0 |
| T12 Events and audit (`events.test.js`) | 11 | 0 |
| PROF Professors (`professors.test.js`) | 7 | 0 |
| SEC Security (`security.test.js`) | 9 | 0 |
| AUTH (`auth.test.js`) | 7 | 0 |
| **Backend total** | **67** | **0** |
| FE Frontend (NoticeForm, NoticeEditor, ProtectedRoute) | 8 | 0 |
| Smoke test against the running server (`npm run smoke`) | 75 checks | 0 |

## Application routes

| Route | Who |
|---|---|
| `/`, `/notices`, `/notices/:id`, `/events`, `/professors`, `/login`, `/register` | Everyone |
| `/author/notices`, `/author/notices/new`, `/author/notices/:id/edit`, `/author/notices/:id/preview`, `/author/notices/:id/revise` | AUTHOR, ADMIN |
| `/reviewer/queue`, `/reviewer/notices/:id`, `/admin/domain-events` | REVIEWER, ADMIN |
| `/admin`, `/admin/professors`, `/admin/users` | ADMIN |

Hidden links are only a convenience. Every permission is enforced by the API
(tests T03-7 and SEC prove a reader cannot call management APIs directly).

## Demo script (matches Section 21)

Run `npm run seed` and `npm run dev`, then:

1. **Register** a new account at `/register`: it becomes a READER. Log out and in again. (AC1)
2. Log in as **author@kdu-uids.test**. Open **My Notices**. (AC2)
3. **New notice**: type a title, press **Save draft**. (AC3)
4. **Preview**: the banner says "PREVIEW - NOT PUBLISHED"; nothing changes. (AC4)
5. Press **Submit for review** with fields empty: every missing field is listed. Fill them and submit. (AC5)
6. Log in as **reviewer@kdu-uids.test**: the notice is in **Review Queue**. (AC6)
7. **Return** it with a reason. As the author, see the reason in My Notices, edit and resubmit. (AC7)
8. As reviewer, **Reject** the seeded "Korean language speaking contest" after the author resubmits it, or any other submitted notice, with a reason. (AC8)
9. **Approve** one notice with **Publish now** and another with **Schedule** (future start). (AC9)
10. Log in as **reader@kdu-uids.test**: only eligible notices are listed; the CAMPUS notice is visible because you are signed in. (AC10)
11. The scheduled "Hospitality management industry visit" and the expired "Course registration period" are not listed, with no background job running. (AC11)
12. As author, on a published notice choose **Create correction**, change the text, add a change note. (AC12)
13. The public page still shows the old text. The seeded "Computer lab maintenance" notice shows the same. (AC13)
14. As reviewer, open the correction from the queue (field diff), **Approve correction**: the new text and an "Updated" date appear. (AC14)
15. Create another correction and **Reject** it: the public version does not change. (AC15)
16. Open the same draft as author and author2 in two browsers (or two private windows) and save in both: the second gets the 409 banner, the typed text is kept, with **Load latest version** and **Copy my changes**. (AC16)
17. As reviewer, **Withdraw** "Final examination timetable": it disappears from list, detail, search, and its PDF link returns 404. (AC17)
18. **Archive** the withdrawn or an expired notice: it is never public. (AC18)
19. Change **priority / pinned** on a published notice: the public order updates. (AC19)
20. As author, add an **event** to a draft in the editor, then submit; reviewer approves. (AC20)
21. As reviewer, **Postpone** the event: same event, new time, old time struck through, reason. (AC21)
22. **Cancel** an event: CANCELLED with the reason, still visible. (AC22)
23. On `/events` switch **List** and **Month**: same events and states. (AC23)
24. Open **Domain Events**: stable UUIDs; repeating an action does not add a record. (AC24)
25. Open `/professors`: filter AI, IBA, BSC, IHM, Korean Studies, EAP; search by name or subject. (AC25, AC26)
26. As admin, **Manage Professors**: add, edit (subjects and counselling hours) and delete. (AC27)
27. Stop and restart the server, refresh the browser: everything persists. (AC28)

## More documentation

- `docs/API.md` - every endpoint, role, request, response and error
- `docs/STATE_MACHINE.md` - transition table and Mermaid diagram
- `docs/VISIBILITY_RULES.md` - the single eligibility rule with boundary examples
- `docs/CONTRACTS.md` - public notice, public event and domain-event payloads for Member 4
- `docs/DECISIONS.md` - design decisions and deviations
- `docs/AUTHOR_REVIEWER_GUIDE.md` - plain-language guide
- `docs/api.http` - ready-to-run requests (VS Code REST Client)
