/* Shared ESLint config for both workspaces. Prettier handles formatting. */
module.exports = {
  root: true,
  ignorePatterns: ['node_modules', 'dist', 'storage', 'coverage'],
  extends: ['eslint:recommended', 'prettier'],
  parserOptions: { ecmaVersion: 2022 },
  overrides: [
    {
      files: ['server/**/*.js'],
      env: { node: true, es2022: true, jest: true },
      parserOptions: { sourceType: 'script' },
      rules: { 'no-console': 'warn' },
    },
    {
      files: ['client/**/*.{js,jsx}'],
      env: { browser: true, es2022: true },
      parserOptions: { sourceType: 'module', ecmaFeatures: { jsx: true } },
      plugins: ['react', 'react-hooks'],
      extends: ['plugin:react/recommended', 'plugin:react/jsx-runtime', 'plugin:react-hooks/recommended'],
      settings: { react: { version: '18.3' } },
      rules: { 'react/prop-types': 'off', 'react/no-unescaped-entities': 'off' },
    },
    {
      files: ['client/**/*.test.{js,jsx}', 'client/src/test/**', 'client/vite.config.js'],
      env: { node: true },
      globals: { vi: 'readonly', describe: 'readonly', test: 'readonly', expect: 'readonly', beforeEach: 'readonly' },
    },
  ],
};
