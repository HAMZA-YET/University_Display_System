'use strict';

/**
 * ==========================================================================
 * TEMPORARY EXTERNAL INTEGRATION BOUNDARY - replace with Member 1 gateway
 * ==========================================================================
 * Local MVP adapter for attachments. It implements the attachmentGateway
 * interface so it can be swapped without touching the publishing module.
 *
 * - Accepts PDF, PNG, JPG and DOCX only, maximum 10 MB.
 * - Checks both the file extension and the magic bytes.
 * - Stores files outside any public folder (UPLOAD_DIR) under random names.
 * - Sets validationStatus VALID or REJECTED. Rejected files are not stored.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const StoredFile = require('./storedFile.model');
const { loadEnv } = require('../../config/env');

const MAX_BYTES = 10 * 1024 * 1024;

const TYPES = {
  pdf: { mime: 'application/pdf', magic: [Buffer.from('%PDF-')] },
  png: { mime: 'image/png', magic: [Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])] },
  jpg: { mime: 'image/jpeg', magic: [Buffer.from([0xff, 0xd8, 0xff])] },
  jpeg: { mime: 'image/jpeg', magic: [Buffer.from([0xff, 0xd8, 0xff])] },
  docx: {
    mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    magic: [Buffer.from([0x50, 0x4b, 0x03, 0x04])],
  },
};

function uploadDir() {
  const dir = path.resolve(process.cwd(), loadEnv().UPLOAD_DIR);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function safeFileName(name) {
  const base = path.basename(String(name || 'file')).replace(/[^\w.\- ]+/g, '_').trim();
  return base.slice(0, 150) || 'file';
}

function detect(file) {
  const ext = path.extname(file.originalname || '').slice(1).toLowerCase();
  const type = TYPES[ext];
  if (!type) return { ok: false, reason: 'Only PDF, PNG, JPG and DOCX files are allowed.' };
  if (!file.buffer || file.size > MAX_BYTES) return { ok: false, reason: 'The file is larger than 10 MB.' };
  const matches = type.magic.some((m) => file.buffer.length >= m.length && file.buffer.subarray(0, m.length).equals(m));
  if (!matches) return { ok: false, reason: 'The file content does not match its extension.' };
  if (ext === 'docx' && !file.buffer.includes(Buffer.from('word/'))) {
    return { ok: false, reason: 'The file is not a valid Word document.' };
  }
  return { ok: true, mime: type.mime };
}

function toMetadata(doc) {
  return {
    fileId: doc.fileId,
    fileName: doc.fileName,
    fileType: doc.fileType,
    size: doc.size,
    validationStatus: doc.validationStatus,
    uploader: doc.uploader,
    rejectionReason: doc.rejectionReason || null,
  };
}

async function upload(file, uploader) {
  const fileId = crypto.randomBytes(16).toString('hex');
  const check = detect(file);
  const record = {
    fileId,
    fileName: safeFileName(file.originalname),
    fileType: check.ok ? check.mime : String(file.mimetype || 'application/octet-stream').slice(0, 100),
    size: file.size,
    validationStatus: check.ok ? 'VALID' : 'REJECTED',
    rejectionReason: check.ok ? null : check.reason,
    uploader: uploader._id,
    storageKey: null,
  };
  if (check.ok) {
    const storageKey = crypto.randomBytes(24).toString('hex');
    await fs.promises.writeFile(path.join(uploadDir(), storageKey), file.buffer, { flag: 'wx' });
    record.storageKey = storageKey;
  }
  const doc = await StoredFile.create(record);
  return toMetadata(doc);
}

async function getMetadata(fileId) {
  if (typeof fileId !== 'string' || !/^[a-f0-9]{32}$/.test(fileId)) return null;
  const doc = await StoredFile.findOne({ fileId }).lean();
  return doc ? toMetadata(doc) : null;
}

async function openStream(fileId) {
  if (typeof fileId !== 'string' || !/^[a-f0-9]{32}$/.test(fileId)) return null;
  const doc = await StoredFile.findOne({ fileId, validationStatus: 'VALID' }).select('+storageKey').lean();
  if (!doc || !doc.storageKey || !/^[a-f0-9]{48}$/.test(doc.storageKey)) return null;
  const full = path.join(uploadDir(), doc.storageKey);
  try {
    await fs.promises.access(full, fs.constants.R_OK);
  } catch (err) {
    return null;
  }
  return fs.createReadStream(full);
}

module.exports = { upload, getMetadata, openStream, MAX_BYTES };
