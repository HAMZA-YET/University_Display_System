import { createContext, useCallback, useEffect, useMemo, useState } from 'react';
import * as authApi from '../api/auth';
import { onUnauthorized } from '../api/client';

export const AuthContext = createContext(null);

/**
 * Holds the signed-in user. The server is the source of truth: the role
 * shown here only decides which links are rendered.
 */
export function AuthProvider({ children, initialUser }) {
  const [user, setUser] = useState(initialUser === undefined ? null : initialUser);
  const [loading, setLoading] = useState(initialUser === undefined);

  useEffect(() => {
    onUnauthorized(() => setUser(null));
    if (initialUser !== undefined) return;
    let active = true;
    authApi
      .me()
      .then((u) => active && setUser(u))
      .catch(() => active && setUser(null))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [initialUser]);

  const login = useCallback(async (email, password) => {
    const u = await authApi.login(email, password);
    setUser(u);
    return u;
  }, []);

  const register = useCallback(async (name, email, password) => {
    const u = await authApi.register(name, email, password);
    setUser(u);
    return u;
  }, []);

  const logout = useCallback(async () => {
    try {
      await authApi.logout();
    } finally {
      setUser(null);
    }
  }, []);

  const hasRole = useCallback((...roles) => Boolean(user && roles.includes(user.role)), [user]);

  const value = useMemo(() => ({ user, loading, login, register, logout, hasRole }), [user, loading, login, register, logout, hasRole]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
