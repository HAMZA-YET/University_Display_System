import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * useApi(fetcher, deps) -> { data, error, loading, reload, setData }
 * Runs the fetcher when deps change and ignores stale responses.
 */
export default function useApi(fetcher, deps = []) {
  const [state, setState] = useState({ data: null, error: null, loading: true });
  const requestRef = useRef(0);
  const fetcherRef = useRef(fetcher);
  fetcherRef.current = fetcher;

  const run = useCallback(async () => {
    requestRef.current += 1;
    const id = requestRef.current;
    setState((s) => ({ ...s, loading: true, error: null }));
    try {
      const data = await fetcherRef.current();
      if (id === requestRef.current) setState({ data, error: null, loading: false });
    } catch (error) {
      if (id === requestRef.current) setState({ data: null, error, loading: false });
    }
  }, []);

  useEffect(() => {
    run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  const setData = useCallback((updater) => {
    setState((s) => ({ ...s, data: typeof updater === 'function' ? updater(s.data) : updater }));
  }, []);

  return { ...state, reload: run, setData };
}
