export default function Footer() {
  return (
    <footer className="footer">
      <div className="container stack">
        <div>
          <strong>KDU Global (Kyungdong University)</strong> - University Information Display System, team plan UIDS-03.
          Member 2 module: notice publishing, events and professor directory.
        </div>
        <div>
          Sample data notice: all professor names, contact details, notices and events shown in this MVP are fictional
          sample data and do not describe real people or real university contact details. Department names are editable
          sample data pending confirmation by the university.
        </div>
        <div>All times are shown in Korea Standard Time (Asia/Seoul).</div>
      </div>
    </footer>
  );
}
