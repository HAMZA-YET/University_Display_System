import { useEffect, useState } from 'react';
import { NavLink, Link, useLocation, useNavigate } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';
import { pendingCount } from '../../api/notices';
import Icon from '../ui/Icon';

/** Unauthorized links are not rendered. The server still enforces every rule. */
export default function NavBar() {
  const { user, hasRole, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const [pending, setPending] = useState(null);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => setOpen(false), [location.pathname]);

  useEffect(() => {
    let active = true;
    if (hasRole('REVIEWER', 'ADMIN')) {
      pendingCount()
        .then((n) => active && setPending(n))
        .catch(() => active && setPending(null));
    } else {
      setPending(null);
    }
    return () => {
      active = false;
    };
  }, [hasRole, location.pathname]);

  async function handleLogout() {
    await logout();
    navigate('/');
  }

  return (
    <header className="topbar">
      <div className="container topbar-inner">
        <Link to="/" className="brand">
          <span className="brand-mark" aria-hidden="true">
            KDU
          </span>
          <span className="brand-text">
            KDU Global UIDS
            <small>University Information Display System</small>
          </span>
        </Link>
        <button
          type="button"
          className="menu-button"
          aria-expanded={open}
          aria-controls="main-nav"
          onClick={() => setOpen((v) => !v)}
        >
          <Icon name={open ? 'close' : 'menu'} />
          <span className="visually-hidden">{open ? 'Close menu' : 'Open menu'}</span>
        </button>
        <nav id="main-nav" className={`nav-links ${open ? 'open' : ''}`} aria-label="Main">
          <NavLink to="/" end>
            Home
          </NavLink>
          <NavLink to="/notices">Notices</NavLink>
          <NavLink to="/events">Events</NavLink>
          <NavLink to="/professors">Professors</NavLink>
          {hasRole('AUTHOR', 'ADMIN') && <NavLink to="/author/notices">My Notices</NavLink>}
          {hasRole('REVIEWER', 'ADMIN') && (
            <NavLink to="/reviewer/queue">
              Review Queue
              {pending !== null && (
                <span className="nav-count" aria-label={`${pending} pending`}>
                  {pending}
                </span>
              )}
            </NavLink>
          )}
          {hasRole('ADMIN') && (
            <>
              <NavLink to="/admin" end>
                Admin Dashboard
              </NavLink>
              <NavLink to="/admin/professors">Manage Professors</NavLink>
              <NavLink to="/admin/users">Users</NavLink>
            </>
          )}
          {hasRole('REVIEWER') && <NavLink to="/admin/domain-events">Domain Events</NavLink>}
          {user ? (
            <>
              <span className="nav-user">
                <Icon name="user" size={14} /> {user.name} ({user.role})
              </span>
              <button type="button" className="linklike" onClick={handleLogout}>
                Log out
              </button>
            </>
          ) : (
            <NavLink to="/login">Login</NavLink>
          )}
        </nav>
      </div>
    </header>
  );
}
